#include "lqr.h"

/*Designed in Matlab*/


K_Matrix_t My_K_Matrix = {

.wheell_K = {
   -2.2361,   -4.1564,  -17.7826,   -1.0971,    -0.7071,    -0.7156
},
.wheelr_K = {
    -2.2361,   -4.1564,  -17.7826,   -1.0971 ,  0.7071 ,  0.7156
},

};















