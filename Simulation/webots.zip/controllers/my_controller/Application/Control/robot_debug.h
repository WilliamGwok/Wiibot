#ifndef __ROBOT_DEBUG_H
#define __ROBOT_DEBUG_H

#include "config_environment.h"
#include "state_var.h"
#include "straight_leg_model.h"

void Debug_State_Var(void);
void Debug_LQR(void);

#endif


