#ifndef __CONFIG_MEC_H
#define __CONFIG_MEC_H

#define WHEEL_RADIUS 0.044

#endif