#ifndef __CONFIG_MEC_H
#define __CONFIG_MEC_H

#include "stm32f4xx_hal.h"

/******************************ȫ��ʹ��ö��******************************/

#define WHEEL_RADIUS 0.044f

#define TIME_BASE 0.001f

#endif
