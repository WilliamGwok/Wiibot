#ifndef __DEV_ALL_H
#define __DEV_ALL_H

#include "stm32f4xx_hal.h"
#include "motor.h"
#include "stdbool.h"
#include "wheel_motor.h"
#include "sd_motor.h"

void My_Device_Init(void);

#endif


