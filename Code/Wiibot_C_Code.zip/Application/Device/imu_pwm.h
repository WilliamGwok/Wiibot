#ifndef IMU_PWM_H
#define IMU_PWM_H
#include "struct_typedef.h"

extern void Imu_PWM_Set(fp32 temp);
void Imu_PWM_Init(void);

#endif

